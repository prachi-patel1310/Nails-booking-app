# Nails Booking App
Step 2-4 of Nails Booking App: Choose Service, Add-Ons, and Confirm Booking. Hosted on GitHub Pages.